class Button{
	
	constructor(text, color, x, y, onclick){
		this.text = text;
		this.color = color;
		this.x = x;
		this.y = y;
		this.onclick = onclick;
	}
}