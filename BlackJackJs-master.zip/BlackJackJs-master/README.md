# BlackJackJs  
Black jack game made in Javascript with CreateJs  
[demo](https://oli8.github.io/BlackJackJs)  

Click on a chip to bet and start playing !  

## Chips Values :  
500 : ![500](https://raw.githubusercontent.com/Oli8/BlackJackJs/master/assets/PNG/Chips/chipBlueWhite_side.png)  
100 : ![100](https://raw.githubusercontent.com/Oli8/BlackJackJs/master/assets/PNG/Chips/chipBlackWhite_side.png)   
25 : ![25](https://raw.githubusercontent.com/Oli8/BlackJackJs/master/assets/PNG/Chips/chipGreenWhite_side.png)    
5 : ![5](https://raw.githubusercontent.com/Oli8/BlackJackJs/master/assets/PNG/Chips/chipRedWhite_side.png)    
1: ![1](https://raw.githubusercontent.com/Oli8/BlackJackJs/master/assets/PNG/Chips/chipWhiteBlue_side.png)  

## Options :
**Double**  
**Insurance**  
**Give up**  

Thanks to [Kenney Vleugels](http://www.kenney.nl) for the assets!  
